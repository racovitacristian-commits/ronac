module.exports = function (eleventyConfig) {
  // --- Markdown filters (for CMS-authored rich text) ---
  const markdownIt = require("markdown-it");
  const md = markdownIt({ html: true, linkify: true, breaks: false });
  eleventyConfig.addFilter("markdown", (s) => (s ? md.render(String(s)) : ""));
  eleventyConfig.addFilter("markdownInline", (s) => (s ? md.renderInline(String(s)) : ""));

  // --- Passthrough static files ---
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });
  eleventyConfig.addPassthroughCopy({ "src/admin": "admin" });
  eleventyConfig.addPassthroughCopy({ "src/robots.txt": "robots.txt" });
  eleventyConfig.addPassthroughCopy({ "src/_redirects": "_redirects" });
  eleventyConfig.addPassthroughCopy({ "src/_headers": "_headers" });

  // --- Collections: archive editions, newest first ---
  eleventyConfig.addCollection("editions", function (collectionApi) {
    return collectionApi
      .getFilteredByTag("edition")
      .sort((a, b) => Number(b.data.year) - Number(a.data.year));
  });

  // --- Filters ---
  eleventyConfig.addFilter("where", function (arr, key, val) {
    return (arr || []).filter((item) => item[key] === val);
  });
  eleventyConfig.addFilter("default", function (value, fallback) {
    return value === undefined || value === null || value === "" ? fallback : value;
  });

  // --- Watch CSS/JS for live reload ---
  eleventyConfig.addWatchTarget("src/assets/");

  return {
    dir: {
      input: "src",
      output: "_site",
      includes: "_includes",
      data: "_data"
    },
    htmlTemplateEngine: "njk",
    markdownTemplateEngine: "njk",
    templateFormats: ["njk", "md", "html"]
  };
};
